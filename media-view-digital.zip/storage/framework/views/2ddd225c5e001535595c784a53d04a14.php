<div class="hidden sm:block">
    <div class="py-8">
        <div class="border-t border-gray-200"></div>
    </div>
</div>
<?php /**PATH /home/joel/Desarrollo/otros/media-view-digital/resources/views/components/section-border.blade.php ENDPATH**/ ?>