
<?php /**PATH /home/joel/Desarrollo/clientes/cesar/media-view-digital/resources/views/components/authentication-card-logo.blade.php ENDPATH**/ ?>