<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between gap-4">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                Registro de radio #<?php echo e($registro->id); ?>

            </h2>

            <a href="<?php echo e(route('m-radio-index')); ?>" class="inline-flex items-center rounded-lg bg-gray-700 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">
                Volver
            </a>
        </div>
     <?php $__env->endSlot(); ?>

    <?php
        $archivos = [];
        if (is_array($registro->archivos)) {
            $archivos = $registro->archivos;
        } elseif (is_string($registro->archivos) && $registro->archivos !== '') {
            $archivos = json_decode($registro->archivos, true) ?: [];
        }
    ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="bg-white rounded-2xl shadow p-6 space-y-6">
                <div class="border-b pb-4">
                    <h3 class="text-lg font-bold text-gray-800">Información general</h3>
                    <p class="text-sm text-gray-500">Detalle completo del registro de radio capturado.</p>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div><p class="text-xs font-semibold text-gray-500 uppercase">ID</p><p class="text-gray-800 font-medium"><?php echo e($registro->id); ?></p></div>
                    <div><p class="text-xs font-semibold text-gray-500 uppercase">Fecha de publicación</p><p class="text-gray-800 font-medium"><?php echo e($registro->publicacion_fecha ? \Carbon\Carbon::parse($registro->publicacion_fecha)->format('d/m/Y') : 'Sin fecha'); ?></p></div>
                    <div><p class="text-xs font-semibold text-gray-500 uppercase">Fecha de registro</p><p class="text-gray-800 font-medium"><?php echo e($registro->created_at ? \Carbon\Carbon::parse($registro->created_at)->format('d/m/Y H:i') : 'Sin fecha'); ?></p></div>
                    <div><p class="text-xs font-semibold text-gray-500 uppercase">Sujeto</p><p class="text-gray-800 font-medium"><?php echo e($registro->sujeto_nombre ?? 'Sin sujeto'); ?></p></div>
                    <div><p class="text-xs font-semibold text-gray-500 uppercase">Organización política</p><p class="text-gray-800 font-medium"><?php echo e($registro->organizacion_nombre ?? 'Sin organización'); ?></p></div>
                    <div><p class="text-xs font-semibold text-gray-500 uppercase">Periodo</p><p class="text-gray-800 font-medium"><?php echo e($registro->periodo_nombre ?? 'Sin periodo'); ?></p></div>
                    <div><p class="text-xs font-semibold text-gray-500 uppercase">Etapa del sujeto</p><p class="text-gray-800 font-medium"><?php echo e($registro->etapa_sujeto ? str_replace('_', ' ', ucfirst($registro->etapa_sujeto)) : 'Sin etapa'); ?></p></div>
                    <div><p class="text-xs font-semibold text-gray-500 uppercase">Tipo de elección</p><p class="text-gray-800 font-medium"><?php echo e($registro->tipo_eleccion_nombre ?? 'Sin tipo de elección'); ?></p></div>
                    <div><p class="text-xs font-semibold text-gray-500 uppercase">Género del autor</p><p class="text-gray-800 font-medium"><?php echo e($registro->genero_autor_nombre ?? 'Sin género'); ?></p></div>
                    <div><p class="text-xs font-semibold text-gray-500 uppercase">Nombre del autor</p><p class="text-gray-800 font-medium"><?php echo e($registro->nombre_autor ?: 'Sin autor'); ?></p></div>
                </div>

                <div class="border-t pt-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4">Datos del medio</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Nombre</p><p class="text-gray-800 font-medium"><?php echo e($registro->medio_nombre ?: 'Sin medio'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Siglas</p><p class="text-gray-800 font-medium"><?php echo e($registro->medio_siglas ?: 'Sin siglas'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Banda</p><p class="text-gray-800 font-medium"><?php echo e($registro->medio_banda ?: 'Sin banda'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Grupo radiofónico</p><p class="text-gray-800 font-medium"><?php echo e($registro->medio_grupo_radiofonico ?: 'Sin grupo'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Municipio</p><p class="text-gray-800 font-medium"><?php echo e($registro->municipio_nombre ?? 'Sin municipio'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Cobertura</p><p class="text-gray-800 font-medium"><?php echo e($registro->medio_cobertura ?: 'Sin cobertura'); ?></p></div>
                    </div>
                </div>

                <div class="border-t pt-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4">Datos de la publicación</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Hora</p><p class="text-gray-800 font-medium"><?php echo e($registro->publicacion_hora ? \Carbon\Carbon::parse($registro->publicacion_hora)->format('H:i') : 'Sin hora'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Tiempo</p><p class="text-gray-800 font-medium"><?php echo e($registro->publicacion_tiempo ? $registro->publicacion_tiempo . ' segundos' : 'Sin tiempo'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Tipo</p><p class="text-gray-800 font-medium"><?php echo e($registro->publicacion_tipo ?: 'Sin tipo'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Ubicación</p><p class="text-gray-800 font-medium"><?php echo e($registro->publicacion_ubicacion ?: 'Sin ubicación'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Modalidad</p><p class="text-gray-800 font-medium"><?php echo e($registro->publicacion_modalidad ?: 'Sin modalidad'); ?></p></div>
                    </div>
                </div>

                <div>
                    <p class="text-xs font-semibold text-gray-500 uppercase mb-1">Observaciones</p>
                    <div class="rounded-xl border border-gray-200 bg-gray-50 p-4 text-gray-700"><?php echo e($registro->observaciones ?: 'Sin observaciones'); ?></div>
                </div>

                <div class="border-t pt-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4">Análisis cualitativo</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Valoración</p><p class="text-gray-800 font-medium"><?php echo e($registro->cuali_valoracion ?: 'Sin valoración'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Lenguaje inclusivo</p><p class="text-gray-800 font-medium"><?php echo e($registro->cuali_lenguaje_inclusivo ?: 'Sin dato'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Estereotipo</p><p class="text-gray-800 font-medium"><?php echo e($registro->cuali_estereotipo ?: 'Sin dato'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Tema de violencia</p><p class="text-gray-800 font-medium"><?php echo e($registro->violencia_tema_nombre ?? 'Sin tema'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Candidatura</p><p class="text-gray-800 font-medium"><?php echo e($registro->cuali_tipo_eleccion_nombre ?? 'Sin candidatura'); ?></p></div>
                        <div><p class="text-xs font-semibold text-gray-500 uppercase">Criterio de evaluación</p><p class="text-gray-800 font-medium"><?php echo e($registro->cuali_criterio_evaluacion ?: 'Sin criterio'); ?></p></div>
                    </div>

                    <div class="mt-4">
                        <p class="text-xs font-semibold text-gray-500 uppercase mb-1">Resumen</p>
                        <div class="rounded-xl border border-gray-200 bg-gray-50 p-4 text-gray-700"><?php echo e($registro->cuali_resumen ?: 'Sin resumen'); ?></div>
                    </div>
                </div>

                <div class="border-t pt-6">
                    <h3 class="text-lg font-bold text-gray-800 mb-4">Audios del registro</h3>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(count($archivos) > 0): ?>
                        <div class="space-y-4">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $archivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $archivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="rounded-xl border border-gray-200 bg-gray-50 p-4">
                                    <div class="mb-2 flex items-center justify-between gap-3">
                                        <p class="truncate text-sm font-medium text-gray-700"><?php echo e(basename($archivo)); ?></p>
                                        <a href="<?php echo e(asset('storage/' . $archivo)); ?>" target="_blank" class="text-sm font-medium text-primary-700 hover:underline">Abrir</a>
                                    </div>
                                    <audio controls preload="metadata" class="w-full">
                                        <source src="<?php echo e(asset('storage/' . $archivo)); ?>" type="audio/mpeg">
                                        Tu navegador no soporta el reproductor de audio.
                                    </audio>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    <?php else: ?>
                        <div class="rounded-xl border border-gray-200 bg-gray-50 p-4 text-gray-500">Este registro no tiene audios cargados.</div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                <div class="border-t pt-6 flex flex-col sm:flex-row gap-3 justify-end">
                    <a href="<?php echo e(route('m-radio-testigo', $registro->id)); ?>" target="_blank" class="inline-flex justify-center rounded-lg bg-red-600 px-4 py-2 text-sm font-semibold text-white hover:bg-red-700">
                        Ver testigo PDF
                    </a>
                    <a href="<?php echo e(route('m-radio-index')); ?>" class="inline-flex justify-center rounded-lg bg-gray-700 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-800">
                        Ir a radio
                    </a>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH /home/joel/Desarrollo/otros/media-view-digital/resources/views/medios-radio/show.blade.php ENDPATH**/ ?>