<svg class="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <path d="M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z"/>
  <path d="M9 10h6"/>
  <path d="M12 13V7"/>
  <path d="M9 17h6"/>
</svg><?php /**PATH /home/joel/Desarrollo/clientes/cesar/media-view-digital/storage/framework/views/2737121cad1e553daca742a7a8849484.blade.php ENDPATH**/ ?>