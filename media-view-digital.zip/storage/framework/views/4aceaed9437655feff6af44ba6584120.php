
<?php /**PATH /home/joel/Escritorio/desarrollo/media-view-digital/resources/views/components/authentication-card-logo.blade.php ENDPATH**/ ?>