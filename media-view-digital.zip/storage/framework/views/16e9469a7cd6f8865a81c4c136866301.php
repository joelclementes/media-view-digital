
<?php /**PATH /home/joel/Desarrollo/otros/media-view-digital/resources/views/components/authentication-card-logo.blade.php ENDPATH**/ ?>