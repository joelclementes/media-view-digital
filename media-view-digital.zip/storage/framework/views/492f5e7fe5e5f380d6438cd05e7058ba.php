<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Roles y permisos
        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(session('success')): ?>
                <div class="mb-6 rounded-xl bg-green-100 border border-green-300 text-green-800 px-4 py-3">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($errors->any()): ?>
                <div class="mb-6 rounded-xl bg-red-100 border border-red-300 text-red-800 px-4 py-3">
                    <ul class="list-disc pl-5">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </ul>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

                <div class="bg-white rounded-2xl shadow p-6">
                    <div class="mb-6">
                        <h2 class="text-2xl font-bold text-gray-800">
                            Roles
                        </h2>

                        <p class="text-sm text-gray-500">
                            Crea roles y asígnales permisos.
                        </p>
                    </div>

                    <form action="<?php echo e(route('roles.store')); ?>" method="POST" class="space-y-5 mb-8">
                        <?php echo csrf_field(); ?>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-1">
                                Nombre del rol
                            </label>

                            <input
                                type="text"
                                name="name"
                                class="w-full rounded-xl border-gray-300 focus:border-primary-500 focus:ring-primary-500"
                                placeholder="Ejemplo: Capturista"
                                required
                            >
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">
                                Permisos
                            </label>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-64 overflow-y-auto border rounded-xl p-3 bg-gray-50">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <label class="flex items-center gap-2 text-sm text-gray-700">
                                        <input
                                            type="checkbox"
                                            name="permissions[]"
                                            value="<?php echo e($permission->name); ?>"
                                            class="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                                        >

                                        <span><?php echo e($permission->name); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-sm text-gray-500">
                                        No hay permisos registrados.
                                    </p>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>

                        <div class="flex justify-end">
                            <button
                                type="submit"
                                class="bg-primary-600 hover:bg-primary-700 text-white font-semibold px-5 py-2 rounded-xl shadow"
                            >
                                Crear rol
                            </button>
                        </div>
                    </form>

                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead>
                                <tr class="bg-gray-100 border-b">
                                    <th class="text-left px-4 py-3">Rol</th>
                                    <th class="text-left px-4 py-3">Permisos</th>
                                    <th class="text-center px-4 py-3">Acciones</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="px-4 py-3 font-semibold text-gray-800">
                                            <?php echo e($role->name); ?>

                                        </td>

                                        <td class="px-4 py-3">
                                            <div class="flex flex-wrap gap-1">
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_2 = true; $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                    <span class="text-xs bg-primary-100 text-primary-700 px-2 py-1 rounded-full">
                                                        <?php echo e($permission->name); ?>

                                                    </span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                    <span class="text-xs text-gray-400">
                                                        Sin permisos
                                                    </span>
                                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </div>
                                        </td>

                                        <td class="px-4 py-3 text-center">
                                            <button
                                                type="button"
                                                onclick="abrirModal('modal-role-<?php echo e($role->id); ?>')"
                                                class="bg-primary-500 hover:bg-primary-600 text-white px-3 py-1 rounded-lg"
                                            >
                                                Editar
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3" class="px-4 py-6 text-center text-gray-500">
                                            No hay roles registrados.
                                        </td>
                                    </tr>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="bg-white rounded-2xl shadow p-6">
                    <div class="mb-6">
                        <h2 class="text-2xl font-bold text-gray-800">
                            Permisos
                        </h2>

                        <p class="text-sm text-gray-500">
                            Crea y administra permisos del sistema.
                        </p>
                    </div>

                    <form action="<?php echo e(route('permisos.store')); ?>" method="POST" class="flex flex-col sm:flex-row gap-3 mb-8">
                        <?php echo csrf_field(); ?>

                        <input
                            type="text"
                            name="name"
                            class="flex-1 rounded-xl border-gray-300 focus:border-primary-500 focus:ring-primary-500"
                            placeholder="Ejemplo: registrar_medios_impresos"
                            required
                        >

                        <button
                            type="submit"
                            class="bg-primary-600 hover:bg-primary-700 text-white font-semibold px-5 py-2 rounded-xl shadow"
                        >
                            Crear permiso
                        </button>
                    </form>

                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead>
                                <tr class="bg-gray-100 border-b">
                                    <th class="text-left px-4 py-3">Permiso</th>
                                    <th class="text-center px-4 py-3">Acciones</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="border-b hover:bg-gray-50">
                                        <td class="px-4 py-3 font-medium text-gray-800">
                                            <?php echo e($permission->name); ?>

                                        </td>

                                        <td class="px-4 py-3 text-center">
                                            <button
                                                type="button"
                                                onclick="abrirModal('modal-permission-<?php echo e($permission->id); ?>')"
                                                class="bg-primary-500 hover:bg-primary-600 text-white px-3 py-1 rounded-lg"
                                            >
                                                Editar
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="2" class="px-4 py-6 text-center text-gray-500">
                                            No hay permisos registrados.
                                        </td>
                                    </tr>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="modal-role-<?php echo e($role->id); ?>" class="hidden fixed inset-0 z-50 bg-black/50 items-center justify-center px-4">
            <div class="bg-white w-full max-w-3xl rounded-2xl shadow-xl p-6">
                <div class="flex justify-between items-center mb-6">
                    <div>
                        <h3 class="text-xl font-bold text-gray-800">
                            Editar rol
                        </h3>

                        <p class="text-sm text-gray-500">
                            Modifica el nombre y los permisos asignados.
                        </p>
                    </div>

                    <button
                        type="button"
                        onclick="cerrarModal('modal-role-<?php echo e($role->id); ?>')"
                        class="text-gray-500 hover:text-gray-800 text-2xl"
                    >
                        &times;
                    </button>
                </div>

                <form action="<?php echo e(route('roles.update', $role)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="space-y-5">
                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-1">
                                Nombre del rol
                            </label>

                            <input
                                type="text"
                                name="name"
                                value="<?php echo e($role->name); ?>"
                                class="w-full rounded-xl border-gray-300 focus:border-primary-500 focus:ring-primary-500"
                                required
                            >
                        </div>

                        <div>
                            <label class="block text-sm font-semibold text-gray-700 mb-2">
                                Permisos
                            </label>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-72 overflow-y-auto border rounded-xl p-3 bg-gray-50">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="flex items-center gap-2 text-sm text-gray-700">
                                        <input
                                            type="checkbox"
                                            name="permissions[]"
                                            value="<?php echo e($permission->name); ?>"
                                            <?php if($role->hasPermissionTo($permission->name)): echo 'checked'; endif; ?>
                                            class="rounded border-gray-300 text-primary-600 focus:ring-primary-500"
                                        >

                                        <span><?php echo e($permission->name); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="flex justify-between mt-6">
                        <button
                            type="button"
                            onclick="document.getElementById('delete-role-<?php echo e($role->id); ?>').submit()"
                            class="bg-red-600 hover:bg-red-700 text-white font-semibold px-5 py-2 rounded-xl shadow"
                        >
                            Eliminar
                        </button>

                        <button
                            type="submit"
                            class="bg-primary-600 hover:bg-primary-700 text-white font-semibold px-5 py-2 rounded-xl shadow"
                        >
                            Actualizar
                        </button>
                    </div>
                </form>

                <form id="delete-role-<?php echo e($role->id); ?>" action="<?php echo e(route('roles.destroy', $role)); ?>" method="POST" class="hidden">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div id="modal-permission-<?php echo e($permission->id); ?>" class="hidden fixed inset-0 z-50 bg-black/50 items-center justify-center px-4">
            <div class="bg-white w-full max-w-xl rounded-2xl shadow-xl p-6">
                <div class="flex justify-between items-center mb-6">
                    <div>
                        <h3 class="text-xl font-bold text-gray-800">
                            Editar permiso
                        </h3>

                        <p class="text-sm text-gray-500">
                            Modifica el nombre del permiso.
                        </p>
                    </div>

                    <button
                        type="button"
                        onclick="cerrarModal('modal-permission-<?php echo e($permission->id); ?>')"
                        class="text-gray-500 hover:text-gray-800 text-2xl"
                    >
                        &times;
                    </button>
                </div>

                <form action="<?php echo e(route('permisos.update', $permission)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <label class="block text-sm font-semibold text-gray-700 mb-1">
                        Nombre del permiso
                    </label>

                    <input
                        type="text"
                        name="name"
                        value="<?php echo e($permission->name); ?>"
                        class="w-full rounded-xl border-gray-300 focus:border-primary-500 focus:ring-primary-500"
                        required
                    >

                    <div class="flex justify-between mt-6">
                        <button
                            type="button"
                            onclick="document.getElementById('delete-permission-<?php echo e($permission->id); ?>').submit()"
                            class="bg-red-600 hover:bg-red-700 text-white font-semibold px-5 py-2 rounded-xl shadow"
                        >
                            Eliminar
                        </button>

                        <button
                            type="submit"
                            class="bg-primary-600 hover:bg-primary-700 text-white font-semibold px-5 py-2 rounded-xl shadow"
                        >
                            Actualizar
                        </button>
                    </div>
                </form>

                <form id="delete-permission-<?php echo e($permission->id); ?>" action="<?php echo e(route('permisos.destroy', $permission)); ?>" method="POST" class="hidden">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                </form>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <script>
        function abrirModal(id) {
            const modal = document.getElementById(id);

            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        function cerrarModal(id) {
            const modal = document.getElementById(id);

            modal.classList.remove('flex');
            modal.classList.add('hidden');
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/joel/Desarrollo/clientes/cesar/media-view-digital/resources/views/roles-permisos/index.blade.php ENDPATH**/ ?>