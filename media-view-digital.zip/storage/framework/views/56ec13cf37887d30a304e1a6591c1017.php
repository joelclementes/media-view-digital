
<?php /**PATH /home/joel/Desarrollo/media-view-digital/resources/views/components/authentication-card-logo.blade.php ENDPATH**/ ?>